<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {

}
</script>

<style>
* {
  margin: 0;
  padding: 0;
  list-style: none;
}

body {
  width: 100%;
  background: #000;
}
.ajc {
  display: flex;
  justify-content: center;
  align-items: center;
}

.ac {
  display: flex;
  align-items: center;
}
</style>