<template>
  <div class="wrapper-box">
    <div class="nav-title ajc">
      作品
    </div>
    <div class="wrapper">
      <!-- 正在进行中 -->
      <div class="current ac">
        <img src="@/assets/img/1.png" class="loading-png" alt="">
        一个绘画正在进行中
      </div>

      <!-- 瀑布流 -->
      <div class="content">
        <div class="img-container" @click="go">
          <img class="img-style" src="../../assets/img/1.jpg" alt="1" />
          <div class="save ajc">
            保存
          </div>
        </div>
        <div class="img-container">
          <img class="img-style" src="../../assets/img/2.jpg" alt="2" />
        </div>
        <div class="img-container">
          <img class="img-style" src="../../assets/img/3.jpg" alt="3" />
        </div>
        <div class="img-container">
          <img class="img-style" src="../../assets/img/1.jpg" alt="1" />
        </div>
        <div class="img-container">
          <img class="img-style" src="../../assets/img/2.jpg" alt="2" />
        </div>
        <div class="img-container">
          <img class="img-style" src="../../assets/img/3.jpg" alt="3" />
        </div>
        <div class="img-container">
          <img class="img-style" src="../../assets/img/1.jpg" alt="1" />
        </div>
        <div class="img-container">
          <img class="img-style" src="../../assets/img/2.jpg" alt="2" />
        </div>
        <div class="img-container">
          <img class="img-style" src="../../assets/img/3.jpg" alt="3" />
        </div>
        <div class="img-container">
          <img class="img-style" src="../../assets/img/1.jpg" alt="1" />
        </div>
        <div class="img-container">
          <img class="img-style" src="../../assets/img/2.jpg" alt="2" />
        </div>
        <div class="img-container">
          <img class="img-style" src="../../assets/img/3.jpg" alt="3" />
        </div>
        <div class="img-container">
          <img class="img-style" src="../../assets/img/1.jpg" alt="1" />
        </div>

      </div>


    </div>


  </div>
</template>

<script>

import waterfall from "vue-waterfall2"
export default {
  components: {
    waterfall
  },
  data() {
    return {
      list: [
        {
          img: require('@/assets/img/1.jpg')
        },
        {
          img: require('@/assets/img/2.jpg')
        },
        {
          img: require('@/assets/img/3.jpg')
        }
      ]
    }
  },
  methods:{
    go(){
      this.$router.push('/works/detail')
    }
  }
}
</script>

<style scoped>
.wrapper {
  padding: .2667rem .4267rem;
  box-sizing: border-box;
}

.current {
  width: 9.12rem;
  height: 1.28rem;
  background: linear-gradient(135deg, #506CFF 0%, #66C3FF 51%, #33E1D7 100%);
  border-radius: .32rem;
  color: #FFF;
  font-size: .4267rem;
  margin-bottom: .2667rem;
  padding: 0 .2933rem;
  box-sizing: border-box;

}

.nav-title {
  background-image: url("@/assets/img/index-img/5-1.png");
  background-color: #000;
  position: sticky;
  top: 0;
  color: #FFF;
  z-index: 9999;
  margin-bottom: .2667rem;
  height: 1.1733rem;
  font-size: .5333rem;
  font-weight: 600;
}



.loading-png {
  width: 1.0667rem;
  height: 1.0667rem;
  animation: round 2s linear infinite;
}

@keyframes round {
  100% {
    transform: rotate(360deg);
  }
}

.content {
  column-count: 2;
  column-gap: .2667rem;
}

.img-container {
  break-inside: avoid;
  width: 4.3933rem;
  position: relative;
}


.img-container:nth-child(2n+1) {
  /* padding-left: .1333rem; */
  padding-right: .0667rem;
}

.img-container:nth-child(2n) {
  /* padding-left: .0667rem; */
  padding-right: .1333rem;
  /* margin-left: -12px; */
}

.img-container .img-style {
  width: 100%;
  border-radius: .32rem;
}

/* .img-container:nth-child(2n+1) {
  order: 1;
}

.img-container:nth-child(2n) {
  order: 2;
} */

.save {
  width: 1.1733rem;
  height: .6667rem;
  background: #000000;
  border-radius: .4rem;
  color: #FFFFFF;
  font-size: .32rem;
  position: absolute;
  bottom: .4667rem;
  right: .2667rem;
}
</style>