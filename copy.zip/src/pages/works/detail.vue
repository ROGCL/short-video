<template>
  <div>
    <div class="nav-title ajc">
      详情
    </div>

    <div class="wrapper">
      <img src="../../assets/img/1.jpg" class="img" alt="">

      <div class="tags">
        可爱｜清新｜春天｜草坪｜可爱｜清新｜春天可爱｜清新｜春天｜草坪
      </div>

      <div class="desc-item">
        <span class="desc-title">
          引擎：
        </span>
        通用
      </div>
      <div class="zw"></div>
      <div class="footer ajc">
        <div class="btn-item ajc" >
          重新绘制
        </div>
        <div class="btn-item btn-item2 ajc" @click="save">
          
          保存到相册
        </div>
      </div>


    </div>
  </div>
</template>

<script>
import { sendMessage, device } from '@/util/initChat'
export default {
  mounted(){
window.onSaveComplete = this.onSaveComplete
  },
  methods: {
    onSaveComplete(res){
      console.log('\x1b[34m%s\x1b[0m', 'detail.vue line:43 res', res);
    },
    save() {
      console.log('%cdetail.vue line:47 object', 'color: #007acc;', window.android);
      // window.android.savePicture('https://img1.baidu.com/it/u=3155988012,1977937542&fm=253&fmt=auto&app=138&f=JPG?w=640&h=343')
      sendMessage('savePicture','https://img1.baidu.com/it/u=3155988012,1977937542&fm=253&fmt=auto&app=138&f=JPG?w=640&h=343')
    }
  }
}
</script>

<style scoped>
.nav-title {
  background-color: #000;
  position: sticky;
  top: 0;
  color: #FFF;
  z-index: 9999;
  margin-bottom: .2667rem;
  height: 1.1733rem;
  font-size: .5333rem;
  font-weight: 600;
}

.wrapper {
  padding: .2667rem .4267rem;
  box-sizing: border-box;
}

.img {
  width: 9.1467rem;
  height: 9.1467rem;
  border-radius: .32rem;
  margin-bottom: .5333rem;
}

.tags {
  font-size: .4267rem;
  color: #FFFFFF;
  font-weight: 600;
  margin-bottom: .2667rem;
}

.desc-item {
  font-size: .3733rem;
  color: #FFFFFF;
  margin-bottom: .2667rem;
}

.desc-title {
  color: #808080;
}

.zw {
  height: 1.7333rem;
  background: #000;
  z-index: 999;
}

.footer {
  position: fixed;
  bottom: 0;
  padding-bottom: .4rem;
  left: 50%;
  background: #000;
  transform: translate(-50%);
}

.btn-item {
  width: 4.4267rem;
  height: 1.28rem;
  background: #31373E;
  border-radius: .32rem;
  margin-right: .2933rem;
  color: #FFFFFF;
  font-weight: 600;
  font-size: .4267rem;
}

.btn-item2 {

  background: linear-gradient(135deg, #506CFF 0%, #66C3FF 51%, #33E1D7 100%);
}
</style>