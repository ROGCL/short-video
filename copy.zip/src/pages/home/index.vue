<template>
  <div>
    <!-- 头部背景 -->
    <!-- <div class="header-banner">
    </div> -->
    <div class="top-wrapper">
      <div class="top-nav">
        <div></div>
        <div class="nav-title">AI绘画</div>
        <div class="nav-title2" @click="go('/works')">作品</div>
      </div>
      <div class="cutting ajc">
        <!-- 通用,漫画,写意切换栏 -->
        <div class="toggle">
          <h4 v-for="item in tabs" :key="item.id" :class="{ underline: tabActive === item.id }"
            @click="tabChange(item.id)">
            {{ item.content }}
          </h4>
        </div>
      </div>
    </div>

    <!-- 版心 -->
    <div class="container">
      <!-- 关键词 -->
      <div class="title-public">
        <img src="@/assets/img/index-img/19.png" alt="" class="image-public" />
      </div>
      <!-- 输入框 -->
      <div class="textarea">
        <textarea id="textarea" cols="30" rows="10" placeholder="输入关于画面的关键词，用逗号隔开"></textarea>
      </div>
      <!-- 条件选择框 -->
      <div class="select">
        <!-- 内部图标框 -->
        <div class="select-content" v-for="item in els" :key="item.id" :class="{ borderpub: borderpub === item.id }"
          @click="choose(item.id)">
          蝴蝶
        </div>
      </div>
      <!-- 艺术家标签 -->
      <div v-show="tabActive != 2">
        <div class="title-public">
          <img src="@/assets/img/index-img/20.png" alt="" class="image-public" />
        </div>
        <!-- 梵高选择栏 -->
        <div class="fangao">
          <div class="small-img" v-for="el in li" :key="el.id" @click="find(el.id)">

            <div class="img-box" :class="{ gaofanactive: fangao === el.id }">
              <img :src="el.img" alt="" class="gaofan" />
            </div>

            <div v-if="el.id == gaofan" class="select-wrapper">
              <img src="@/assets/img/index-img/26.png" class="control-img" />
            </div>
            <div class="font-public" v-else>{{ el.content }}</div>
          </div>
        </div>
      </div>
      <!-- 风格选择 -->
      <div v-show="tabActive != 2">
        <div class="title-public">
          <img src="@/assets/img/index-img/21.png" alt="" class="image-public" />
        </div>
        <!-- 画风选择 -->
        <div class="painting">
          <div class="pain" v-for="it in uls" :key="it.id" @click="change(it.id)">
            <div class="pain-img-box">
              <img src="http://open.weixin.qq.com/qr/code?username=develong" class="pain-img" alt=""
                :class="{ activeimg: pain === it.id }" />
            </div>
            <div v-if="it.id == pain" class="select-wrapper">
              <img src="@/assets/img/index-img/26.png" class="control-img" />
            </div>
            <div class="font-public" v-else>{{ it.content }}</div>
          </div>
        </div>
      </div>

      <!-- 参考图 -->
      <div class="title-public">
        <img src="@/assets/img/index-img/22.png" alt="" class="image-public special" />
      </div>
      <!-- 参考图片 -->
      <div class="reference-img ajc">
        <div class="upload-wrapper" @click="uploadImg" v-if="!img">
          <img src="@/assets/img/index-img/27.png" alt="" class="img27">
          <div class="upload-text">
            上传参考图
          </div>
        </div>
        <div v-else class="success-img-box">
          <img :src="img" alt="" class="success-img">
          <div class="reupload ajc" @click="uploadImg">重新上传</div>
        </div>


      </div>
      <!-- 效果图比例 -->
      <div class="title-public">
        <img src="@/assets/img/index-img/23.png" alt="" class="image-public" />
      </div>
      <!-- 比例 -->
      <div class="proportion">
        <div class="proportion-s" v-for="el in list" :key="el.id" @click="proportion(el.id)">
          <div class="proportion-s-box">
            <img :src="el.img" alt="" :class="{ borderpubs: ol === el.id }" class="img1" style="display:block" />
          </div>

          <div v-if="el.id == ol" class="select-wrapper">
            <img src="@/assets/img/index-img/26.png" class="control-img" />
          </div>


          <div class="font-public" v-else>{{ el.content }}</div>
        </div>
      </div>
      <!-- 其他参数 -->
      <div v-show="tabActive != 3">
        <div class="title-public">
          <img src="@/assets/img/index-img/24.png" alt="" class="image-public" />
        </div>
        <!-- 参数配置项 -->
        <div class="props">
          <div class="height1 height-public">
            <h5 class="h5-public">引导力度</h5>
            <van-slider v-model="value" :min="0" :max="100" bar-height="4px" background="rgba(49,55,62,0.5)"
              active-color="
linear-gradient(135deg, #506CFF 0%, #66C3FF 51%, #33E1D7 100%);" class="slider" />
            <span>{{ this.value }}</span>
          </div>

          <div class="slider-bottom-small-box">
            <h5>智能扩展</h5>
            <div class="btn-font-public btn10" v-for="es in spare" :class="{ borderpubs: btn11 === es.id }" :key="es.id"
              @click="chooserBtn(es.id)">{{ es.btn }}</div>
          </div>
          <div class="slider-bottom-small-footer-box">
            <h5>步数设置</h5>
            <div class="btn-font-publics" :class="{ borderpubs: btn12 === es.id }" v-for="es in spares" :key="es.id"
              @click="chooseFtn(es.id)">{{ es.btn }}</div>
          </div>
        </div>
      </div>
      <!-- 选择通道 -->
      <!-- <div class="title-public">
        <img src="@/assets/img/index-img/25.png" alt="" class="image-public" />
      </div>
      <div class="path-road">
        <div class="normal width-public" v-for="item in drawChanels" :key="item.id"
          :class="{ borderpubs: drawActiveId === item.id }" @click="drawChanelClick(item.id)">
          <img :src="item.img" alt="" />
          <h5 class="h5-pub">{{ item.h5 }}</h5>
          <h6 class="h6-pub" v-if="item.id == 1">预计排队99999人</h6>
          <h6 class="h6-pub" v-else>{{ item.h6 }}</h6>
        </div>
      </div> -->
      <!-- 开始绘画按钮 -->
      <!-- <router-link to="/making">
        <div class="begin-btn">开始绘画</div>
      </router-link> -->
      <div class="begin-btn" @click="startDraw">开始绘画</div>
    </div>
    <!-- 弹出层，当没有次数时弹出,有次数直接打开编辑页面 -->
    <div>
      <van-popup v-model="show" position="bottom" :style="{ height: '55%', background: '#000' }">
        <!-- 头部压层 -->
        <div class="popup-header">
          <span @click="close"></span>
          <h4>AI绘画会员包</h4>
        </div>
        <!-- 下方版心 -->
        <div class="bottom-container">
          <!-- 价格目录 -->
          <div class="popup-price-outside-box">
            <div class="popup-price" v-for="(item, index) in combos" :key="item.id"
              :class="{ popuppricechoosepublic: combosActive === index }" @click="combosActiveClick(item, index)">
              <h6 class="tuijian" v-show="item.id === 1">推荐购</h6>
              <!-- 制作次数 -->
              <h3>{{ item.title }}</h3>
              <h4>￥<span>{{ item.price }}</span></h4>
              <!-- 描述文字 -->
              <h5>{{ item.hint1 }}</h5>
            </div>
          </div>
          <!-- 支付方式 -->
          <div class="paypal-outside">
            <div class="paypal" v-for="items in payType" :key="items.id" @click="choosePay(items.id)">
              <img :src="items.icon" alt="" class="zfb">
              <span>{{ items.name }}</span>
              <img :src="require(`@/assets/img/popup/${payTypeActived == items.id ? 4 : 3}.png`)" alt="" class="true">
            </div>
          </div>
          <!-- 立即购买按钮 -->
          <div class="buy" @click="buy">立即购买
          </div>
          <!-- 文字框 -->
          <div class="notice">已阅读并同意<a>《付款授权服务协议》</a>；开通后到期前3天发起续费，可随时在支付宝关闭续费扣费。</div>
        </div>
      </van-popup>
    </div>
  </div>
</template>

<script>
import { sendMessage, device } from '@/util/initChat'
export default {
  data() {
    return {
      list: [
        {
          id: 1,
          img: require("@/assets/img/index-img/10.png"),
          content: "1:1",
        },
        {
          id: 2,
          img: require("@/assets/img/index-img/11.png"),
          content: "3:4",
        },
        {
          id: 3,
          img: require("@/assets/img/index-img/8.png"),
          content: "4:3",
        },
        {
          id: 4,
          img: require("@/assets/img/index-img/13.png"),
          content: "9:16",
        },
        {
          id: 5,
          img: require("@/assets/img/index-img/8.png"),
          content: "16:9",
        },
      ],
      ol: 1,
      els: [
        {
          id: 1,
          content: "蝴蝶",
        },
        {
          id: 2,
          content: "蝴蝶",
        },
        {
          id: 3,
          content: "蝴蝶",
        },
        {
          id: 4,
          content: "蝴蝶",
        },
        {
          id: 5,
          content: "蝴蝶",
        },
        {
          id: 6,
          content: "蝴蝶",
        },
        {
          id: 7,
          content: "蝴蝶",
        },
        {
          id: 8,
          content: "蝴蝶",
        },
        {
          id: 9,
          content: "蝴蝶",
        },
        {
          id: 10,
          content: "蝴蝶",
        },
      ],
      borderpub: 1,
      li: [
        {
          id: 1,
          img: require("@/assets/img/index-img/7.png"),
          content: "梵高1",
        },
        {
          id: 2,
          img: require("@/assets/img/index-img/7.png"),
          content: "梵高2",
        },
        {
          id: 3,
          img: require("@/assets/img/index-img/7.png"),
          content: "梵高3",
        },
        {
          id: 4,
          img: require("@/assets/img/index-img/7.png"),
          content: "梵高4",
        },
        {
          id: 5,
          img: require("@/assets/img/index-img/7.png"),
          content: "梵高5",
        },
        {
          id: 6,
          img: require("@/assets/img/index-img/7.png"),
          content: "梵高6",
        },
        {
          id: 7,
          img: require("@/assets/img/index-img/7.png"),
          content: "梵高7",
        },
        {
          id: 8,
          img: require("@/assets/img/index-img/7.png"),
          content: "梵高8",
        },
      ],
      fangao: 1,
      gaofan: 1,
      uls: [
        {
          id: 1,
          content: "梵高1",
        },
        {
          id: 2,
          content: "梵高2",
        },
        {
          id: 3,
          content: "梵高3",
        },
        {
          id: 4,
          content: "梵高4",
        },
        {
          id: 5,
          content: "梵高5",
        },
        {
          id: 6,
          content: "梵高6",
        },
        {
          id: 7,
          content: "梵高7",
        },
        {
          id: 8,
          content: "梵高8",
        },
      ],
      // 上传之后的url地址
      img: '',
      // 选择绘画通道的方式
      drawActiveId: 1,
      // 选择绘画方式
      drawChanels: [
        {
          id: 1,
          img: require("@/assets/img/index-img/2.png"),
          h5: "普通",
        },
        {
          id: 2,
          img: require("@/assets/img/index-img/1.png"),
          h5: "VIP加速",
          h6: "优先使用服务器制作",
        },
      ],
      spare: [
        {
          id: 1,
          btn: "色彩狂化",

        },
        {
          id: 2,
          btn: "面部强化"
        },
      ],
      spares: [
        {
          id: 1,
          btn: "常规",

        },
        {
          id: 2,
          btn: "加长"
        },
      ],
      payType: [
        {
          name: "支付宝",
          id: 1,
          icon: require("@/assets/img/popup/8.png"),
        },
        {
          name: "微信",
          id: 2,
          icon: require("@/assets/img/popup/6.png"),
        },
      ],
      show: false,
      pain: 1,
      active: 1,
      value: 48,
      h4: 1,

      payTypeActived: 1,
      btn11: 1,
      btn12: 1,
      userinfo: {}, // 用户信息
      combos: [], // 支付套餐信息
      combosActive: 0,
      tabActive: 1,
      tabs: [
        {
          id: 1,
          content: "通用",
        },
        {
          id: 2,
          content: "漫画",
        },
        {
          id: 3,
          content: "写意",
        },
      ],
    };
  },

  mounted() {
    // 暴露方法给APP
    window.onPageResume = this.onPageResume   // 刷新
    window.getAppParams = this.getAppParams  // 获取用户信息
    window.onPaySuccess = this.onPaySuccess  // 支付成功
    window.onPhotoSelectComplete = this.onPhotoSelectComplete  // 上传图片完成
    this.getAppDown();
    // 获取APP参数
    this.getUserinfo()
    // 获取套餐信息
    this.getCombsInfo()
  },
  methods: {
    /**
     * 暴露给APP的方法
     * 1.刷新页面的时候重新去获取APP的用户信息
     */
    onPageResume() {
      this.getUserinfo()
    },

    getAppParams(res) {
      // console.log('%cindex-pages.vue line:454 22', 'color: #007acc;', 22);
    },

    // 原生app支付成功
    onPaySuccess(res) {
      this.getUserinfo()
    },
    /**
     * 获取用户信息，如果没有用户信息表示没有登录；需要跳转登录
     */
    getUserinfo() {
      let userinfo = sendMessage('getUserInfo')

      if (userinfo) {
        this.userinfo = JSON.parse(userinfo)
        console.log('%cindex-pages.vue line:468 userinfo', 'color: #007acc;', this.userinfo);
      } else {
        sendMessage('jumpClientFunction', { linkType: 3000 })
      }
    },

    // 获取套餐信息
    async getCombsInfo() {
      const [err, res] = await this.$http.post(`api/v6.Aipainting/combos`, {
        platform: device.system
      })
      if (err) return
      this.combos = res.combos
      // 设置默认选择的支付套餐
      this.comboActive = res.combos[0]

    },
    // 点击支付获取支付信息
    async buy() {
      // 安卓走接口
      this.show = false
      if (device.system == 'android') {
        let params = {
          pay_type: this.payTypeActived == 1 ? 'ali' : "wx",
          combo_id: this.comboActive.id,
          platform: device.system,
          uuid: this.userinfo.uuid
        }
        // let params = { "pay_type": "ali", "combo_id": 65, "platform": "android", "uuid": "6226b6b2596751335d449522" }
        const [err, res] = await this.$http.post('api/v6.Aipainting/order', params)
        console.log('支付参数 ', res);
        if (err) return
        let payFun = this.payTypeActived == 1 ? 'openAliPay' : 'openWxPay'
        let payData = this.payTypeActived == 1 ? res.pay_url : res.pay_data
        sendMessage(payFun, payData)
      } else if (device.system == 'ios') {
        //ios走本地方法
        sendMessage('openInternalPurchase', { payParams: this.comboActive })
      }
    },
    // 跳转
    go(path) {
      this.$router.push(path)
    },

    // 点击上传图片
    uploadImg() {
      sendMessage('openPhotoSelect', { selectType: 1, showGif: false })
    },

    // 上传图片完成
    onPhotoSelectComplete(res) {
      this.img = res
      console.log('%cindex.vue line:563 图片', 'color: #007acc;', res);
    },

    /**
 * 点击开始绘画
 * buy_count 为0 就需要拉起支付
 */
    startDraw() {
      if (this.userinfo.buy_count == 0) {
        this.show = true
      }
    },





    getAppDown() {
      let u = navigator.userAgent;
      let isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
      let isAndroid = u.indexOf("Android") > -1 || u.indexOf("Adr") > -1; //android终端
      if (isiOS) {
        console.log("ios");
      } else if (isAndroid) {
        console.log("Android");
      }
    },
    choose(id) {
      this.borderpub = id;
    },
    find(fn) {
      this.fangao = fn;
      this.gaofan = fn;
    },
    change(id) {
      this.pain = id;
    },
    proportion(id) {
      this.ol = id;
    },
    drawChanelClick(id) {
      this.drawActiveId = id;
    },

    tabChange(id) {
      this.tabActive = id;
    },


    close() {
      this.show = false
    },
    combosActiveClick(item, index) {
      this.combosActive = index
      this.comboActive = item
      // this.blue = id
    },
    choosePay(value) {
      this.payTypeActived = value
    },
    chooserBtn(id) {
      this.btn11 = id
    },
    chooseFtn(id) {
      this.btn12 = id
    }
  },
};
</script>

<style scoped>
.header-banner {
  width: 100%;
  height: 6.6667rem;
  background-image: url("@/assets/img/index-img/4.png");
  background-repeat: no-repeat;
  background-size: 100% 100%;
}

.container {
  width: 9.1467rem;
  height: 100vh;
  margin: 0 auto;
}

.title-public {
  margin-top: 0.5333rem;
  margin-bottom: 0.2667rem;
}

.image-public {
  width: 2.6667rem;
  height: 100%;
}

.cutting {
  /* position: sticky; */
  top: 0;
  width: 9.68rem;
  height: 1.1733rem;
  margin-left: 0.16rem;

  /* margin-top: -1.04rem; */
  /* background-image: url("@/assets/img/index-img/5.png"); */
  background-repeat: no-repeat;
  background-size: 100% 100%;
  z-index: 9999;
}

.cutting2 {
  background-image: url("@/assets/img/index-img/5-1.png");
  background-color: #000;
}

.ajc {
  display: flex;
  align-items: center;
  justify-content: center;
}

.toggle {
  /* padding-top: 0.6933rem; */
  /* margin-left: 2.2667rem; */
  display: flex;
  align-items: center;
  margin: 0 auto;
  justify-content: space-between;
  width: 5.12rem;
  height: 0.5867rem;
}

.toggle h4 {
  width: 0.8533rem;
  height: 0.7467rem;
  white-space: nowrap;
  font-weight: normal;
  font-size: 0.4267rem;
  color: #c5c8d4;
}

.underline {
  width: 0.32rem;
  text-align: center;
  border-bottom: 6px solid;
  border-radius: 0.2133rem;
  border-image: linear-gradient(135deg,
      rgba(80, 108, 255, 1),
      rgba(102, 195, 255, 1),
      rgba(51, 225, 215, 1)) 6 6;
  background: linear-gradient(90deg, #506cff 0%, #66c3ff 53%, #33e1d7 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

#textarea {
  width: 9.1467rem;
  height: 1.8933rem;
  margin-top: 0.2667rem;
  resize: none;
  border: none;
  border-radius: 0.1067rem;
  background-image: url("@/assets/img/index-img/16.png");
  background-repeat: no-repeat;
  background: #31373e;
  background-size: 100% 100%;
  font-size: 0.32rem;
  color: #7d808d;
}

#textarea::placeholder {
  font-size: 0.32rem;
  color: #7d808d;

  padding-left: 0.2667rem;
  padding-top: 0.2667rem;
}

.select {
  width: 100%;
  overflow: hidden;
  overflow-x: auto;
  white-space: nowrap;
  z-index: -1;
}

.select::-webkit-scrollbar {
  display: none;
}

.select-content {
  display: inline-block;
  width: 1.8133rem;
  margin-right: 0.2133rem;
  background: #31373e;
  border-radius: 0.16rem;
  line-height: 0.6667rem;
  text-align: center;
  font-size: 0.32rem;
  color: #c5c8d4;
}

.fangao {
  width: 9.1467rem;
  display: flex;
  align-items: center;
  /* height: 3.4933rem; */
  overflow-x: auto;
  white-space: nowrap;
}

.fangao::-webkit-scrollbar {
  display: none;
}

.small-img {
  display: inline-block;
  width: 2.16rem;
  /* height: 3.4933rem; */
  margin-right: 0.32rem;
  text-align: center;
  flex-shrink: 0;
  /** 防止父元素使用了flex子元素宽度被挤压 */
}

.small-img h6 {
  width: 100%;
  height: 0.6133rem;
}

.img-box {
  width: 100%;
  height: 2.88rem;
  margin-bottom: .1067rem;
}

.gaofan {
  width: 100%;
  height: 100%;
  /* padding: .1067rem; */
}

.gaofanactive {
  /* width: 1.9467rem;
  height: 2.6667rem; */
  padding: 0.1067rem;
  border: 0.0267rem solid rgba(51, 225, 215, 1);
  border-radius: 0.16rem;
  box-sizing: border-box;
}

.control-img {
  display: block;
  width: 0.64rem;
  height: 0.4533rem;
  background-repeat: no-repeat;
  background-size: contain;
  text-align: center;
  /* margin: auto; */
  /* margin: 0 auto; */
}

.font-public {
  font-size: 0.32rem;
  color: #7d808d;
  text-align: center;
}

.painting {
  width: 100%;
  /* height: 2.0533rem; */
  display: flex;
  align-items: center;
  overflow-x: auto;
  white-space: nowrap;
}

.painting::-webkit-scrollbar {
  display: none;
}

.pain {
  display: inline-block;
  width: 1.44rem;
  /* height: 1.44rem; */
  margin-right: 0.2667rem;
  flex-shrink: 0;
  text-align: center;
}

.pain-img-box {
  width: 1.44rem;
  height: 1.44rem;
  margin-bottom: .1333rem;
}

.pain-img {
  width: 100%;
  height: 100%
}

.fullimg {
  width: 1.44rem;
  height: 1.44rem;
}

.activeimg {
  padding: 0.1067rem;
  border: 0.0267rem solid rgba(51, 225, 215, 1);
  border-radius: .16rem;
  box-sizing: border-box;
}

.reference-img {
  width: 100%;
  height: 2.6133rem;
  /* background-image: url("@/assets/img/index-img/15.png"); */
  background-repeat: no-repeat;
  background-size: contain;
  /* z-index: -1; */
  background: #31373E;
}

.img27 {
  width: .8533rem;
  height: .8533rem;
  border: 1px dashed #7D808D;
}

.upload-text {
  color: #7D808D;

  font-size: .32rem;
}

.upload-wrapper {
  text-align: center;
}

.special {
  width: 4.6133rem;
}

.proportion {
  width: 100%;
  display: flex;
  align-items: center;
  overflow-x: auto;
  white-space: nowrap;
}

.proportion::-webkit-scrollbar {
  display: none;
}

.proportion-s {
  display: inline-block;
  width: 1.28rem;
  /* height: 100%; */
  margin-right: 0.6933rem;
  flex-shrink: 0;
}

.proportion-s-box {
  width: 1.28rem;
  height: 1.28rem;
  margin-bottom: .1333rem;
}

.img1 {
  width: 100%;
  height: 100%;
}

.props {
  position: relative;
  width: 100%;
  height: 4.8533rem;
  background: rgba(49, 55, 62, 0.5);
  border-radius: 0.2133rem;
}

.height-public {
  color: #c5c8d4;
}

.h5-public {
  font-size: 0.3733rem;
  font-weight: 400;
  color: #c5c8d4;
}

.height1 h5 {
  position: absolute;
  left: 0.5333rem;
  top: 0.5867rem;
}

.slider {
  position: absolute;
  left: 2.56rem;
  top: 0.8267rem;
  width: 5.12rem;
}

.height1 span {
  position: absolute;
  left: 8.2133rem;
  top: 0.6933rem;
  font-size: 0.32rem;
  color: #7d808d;
}

.btn-font-public {
  width: 2.1333rem;
  height: 0.7733rem;
  background: rgba(49, 55, 62, 0.5);
  border-radius: 0.16rem;
  line-height: 0.7733rem;
  font-size: 0.32rem;
  color: #7d808d;
  text-align: center;
}

.btn-font-publics {
  width: 1.4933rem;
  height: .7733rem;
  background: rgba(49, 55, 62, 0.5);
  border-radius: 0.16rem;
  line-height: 0.7733rem;
  font-size: 0.32rem;
  color: #7d808d;
  text-align: center;
}

.slider-bottom-small-box {
  display: flex;
  justify-content: space-between;
  position: relative;
  top: 1.9733rem;
  left: .5333rem;
  width: 8.08rem;
}

.slider-bottom-small-footer-box {
  display: flex;
  justify-content: space-between;
  position: relative;
  top: 2.5333rem;
  margin-left: .5333rem;
  margin-right: .5333rem;
  /* left: .5333rem; */

}

.slider-bottom-small-footer-box h5 {
  font-size: .3733rem;
  color: #C5C8D4;
  font-weight: normal;
  margin-top: .1067rem;
}

.slider-bottom-small-box h5 {
  font-size: .3733rem;
  color: #C5C8D4;
  font-weight: normal;
  margin-top: .1067rem;
}

.path-road {
  display: flex;
  justify-content: space-around;
  width: 100%;
  height: 2.1867rem;
}

.width-public {
  width: 4.4533rem;
  height: 2.1867rem;
  background: #31373e;
  border-radius: 0.2133rem;
}


.success-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.success-img-box {
  width: 100%;
  height: 100%;
  position: relative;
}

.reupload {
  width: 1.6rem;
  height: .6933rem;
  background: rgba(0, 0, 0, 0.8);
  border-radius: .16rem;
  position: absolute;
  bottom: .2667rem;
  right: .2667rem;
  color: #FFFFFF;
  font-size: .2667rem;
}

.normal {
  position: relative;
}

.normal img {
  margin-top: 0.6933rem;
  margin-left: 0.2667rem;
  width: 0.8rem;
  height: 0.8rem;
}

.h5-pub {
  position: absolute;
  left: 1.2267rem;
  top: 0.4267rem;
  font-size: 0.4267rem;
  color: #fff;
}

.h6-pub {
  position: absolute;
  left: 1.2267rem;
  top: 1.2267rem;
  font-size: 0.32rem;
  color: #7d808d;
}

.begin-btn {
  height: 1.28rem;
  margin-top: 0.8rem;
  margin-bottom: 1.2533rem;
  background: linear-gradient(135deg, #506cff 0%, #66c3ff 51%, #33e1d7 100%);
  border-radius: 0.32rem;
  line-height: 1.28rem;
  text-align: center;
  color: #fff;
  font-size: 0.4267rem;
  font-weight: 600;
}

.active {
  background: linear-gradient(90deg, #506cff 0%, #66c3ff 53%, #33e1d7 100%);
}

/* 边框线公共样式 */
.borderpub {
  border-image: linear-gradient(135deg,
      rgba(80, 108, 255, 1),
      rgba(102, 195, 255, 1),
      rgba(51, 225, 215, 1)) 2 2;
  border: 0.0267rem solid;
  clip-path: inset(0 round .1333rem);
  border-radius: .2133rem;
  color: #66C3FF;

}

.borderpubs {
  border: 0.0267rem solid rgba(51, 225, 215, 1);
  border-radius: .2133rem;
  /* border-image: linear-gradient(135deg,
      rgba(80, 108, 255, 1),
      rgba(102, 195, 255, 1),
      rgba(51, 225, 215, 1)) 2 2; */
  /* clip-path: inset(0 round .1333rem); */
}

/* 选中时的图标,公共样式 */
.iconchoosed {
  width: 0.64rem;
  height: 0.4533rem;
  margin: 0 auto;
  /* margin: .1733rem auto 0; */
  background-image: url("@/assets/img/index-img/26.png");
  background-repeat: no-repeat;
  background-size: contain;
}

.popup-header {
  position: relative;
  width: 100%;
  height: 3.8667rem;
  background-image: url('@/assets/img/popup/2.png');
  z-index: -1;
}

.popup-header span {
  position: absolute;
  left: .4267rem;
  top: .1867rem;
  width: .8rem;
  height: .8rem;
  background-image: url('@/assets/img/popup/5.png');
  background-repeat: no-repeat;
  background-size: cover;
}

.popup-header h4 {
  line-height: 1.2933rem;
  text-align: center;
  font-size: .5333rem;
  color: #fff;
}

.bottom-container {
  width: 9.1467rem;
  margin: 0 auto;
}

.popup-price-outside-box {
  display: flex;
  justify-content: space-around;
}

.popup-price {
  position: relative;
  width: 2.9067rem;
  height: 3.4933rem;
  margin-top: -1.8933rem;
  background: #31373E;
  border: 1px solid rgba(0, 0, 0, 0.5);
  border-radius: .32rem;
  z-index: 9999;
}

.popup-price h3 {
  text-align: center;
  font-weight: normal;
  font-size: .3733rem;
  padding-top: .7467rem;
  color: #fff;
}

.popup-price h4 {
  padding-top: .2133rem;
  font-weight: normal;
  text-align: center;
  color: #fff;
  font-size: .32rem;
}

.popup-price h4 span {
  font-size: .6933rem;
}

.popup-price h5 {
  padding-top: .16rem;
  font-weight: normal;
  font-size: .32rem;
  text-align: center;
  color: #fff;
}

/* 第一幅图的推荐购 */
.tuijian {
  position: absolute;
  left: 0;
  top: 0;
  width: 1.4933rem;
  height: .64rem;
  background: #FF5353;
  border-top-left-radius: .32rem;
  border-bottom-right-radius: .32rem;
  font-size: .32rem;
  text-align: center;
  line-height: .64rem;
  color: #fff;
  font-weight: normal;
}

/* 支付选择项动态样式 */
.popuppricechoosepublic {
  background: linear-gradient(135deg, #A4B2FF 0%, #A9DDFF 51%, #99FFF9 100%);
  color: #000;
}

.buy {
  margin-top: .5333rem;
  height: 1.28rem;
  border-radius: .32rem;
  background: linear-gradient(135deg, #506CFF 0%, #66C3FF 51%, #33E1D7 100%);
  text-align: center;
  line-height: 1.28rem;
  color: #fff;
  font-size: .4267rem;
  font-weight: 600;
}

.notice {
  margin-top: .4267rem;
  font-size: .2667rem;
  color: #fff;
}

.notice a {
  color: #66C3FF;
}

.paypal-outside {
  display: flex;
  flex-wrap: nowrap;
  justify-content: space-around;
}

.paypal {
  position: relative;
  margin-top: 1.0667rem;
  width: 2.32rem;
  height: .5333rem;
}

.zfb {
  position: absolute;
  top: .2667rem;
  /* margin-left: .64rem; */
  width: .5333rem;
  height: .5333rem;
  background-repeat: no-repeat;
  background-size: contain;
}

.paypal span {
  display: block;
  position: absolute;
  top: .3333rem;
  padding-left: .6667rem;
  white-space: nowrap;
  width: .96rem;
  height: .4533rem;
  font-size: .32rem;
  color: #fff;
  margin-left: .1067rem;
}

.true {
  position: absolute;
  left: 2.5333rem;
  top: .3067rem;
  width: .4267rem;
  height: .4267rem;
  /* margin-left: 1.3333rem;
  margin-top: -.1067rem; */
}

.select-wrapper {
  display: flex;
  justify-content: center;
}

.top-wrapper {
  background-image: url("@/assets/img/index-img/5-1.png");
  background-color: #000;
  width: 10rem;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  position: sticky;
  top: 0;
  z-index: 99999;
}

.top-nav {
  height: 1.1733rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: .2667rem;
  padding: 0 .4267rem;
  box-sizing: border-box;
  position: relative;
}

.nav-title {

  color: #FFF;
  font-size: .5333rem;
  font-weight: 600;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.nav-title2 {

  font-size: .3733rem;
  border-image: linear-gradient(135deg,
      rgba(80, 108, 255, 1),
      rgba(102, 195, 255, 1),
      rgba(51, 225, 215, 1)) 6 6;
  background: linear-gradient(90deg, #506cff 0%, #66c3ff 53%, #33e1d7 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
</style>

